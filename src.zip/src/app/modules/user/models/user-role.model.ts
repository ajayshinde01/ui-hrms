export interface UserRole {
  id: string;
  name: String;
  description: String;
  containerId: String;
  clientRole: String;
}
