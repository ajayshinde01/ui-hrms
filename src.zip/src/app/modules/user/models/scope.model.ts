export interface Scope {
  id: string;
  name: String;
  displayName: String;
}
