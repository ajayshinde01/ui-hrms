export interface Employee {
    id: number;
    employeeTypeId:string;
    type: string;
    orgCode: string;
    createdBy: string;
    updatedBy:string;
    createdAt:string;
    updatedAt:string;

}