export interface ColumnsMetadata {
  name: any;
  mappedBy: string;
  sortBy: string;
  type: string;
  width: number;
}
