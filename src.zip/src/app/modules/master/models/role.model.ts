export interface Role {
  id: number;
  roleName: string;
  roleId: string;
  orgCode: string;
  createdBy: string;
  created_at: string;
  updated_by: string;
  updated_at: string;
}
