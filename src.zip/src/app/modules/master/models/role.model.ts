export interface Role {
  id: number;
  roleName: string;
  roleId: string;
  orgCode: string;
  createdBy: string;
  createdAt: string;
  updatedBy: string;
  updatedAt: string;
}
