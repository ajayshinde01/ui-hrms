export interface GradeType {
  commonMstId: number;
  code: string;
  value: string;
  priority: string;
}
