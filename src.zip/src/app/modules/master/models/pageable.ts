export interface Pagination {
  pageSize: number;

  serchingParmeter?: string;

  sortKey?: string;

  sortType?: string;

  sortBy?: string;

  pageNumber: number;
}
