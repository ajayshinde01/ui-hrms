export interface Visa {
    id: number;
    countryCode: String;
    visaNumber: String;
    validDate: String;
    visaFile: String;
    orgCode: String;
    createdBy: String;
    updatedBy: String;
  }