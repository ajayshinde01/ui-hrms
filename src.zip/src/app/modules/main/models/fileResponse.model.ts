export interface FileResponse {
  message: String;
  dateTime: String;
  fileName: String;
}
