export interface ApiResponse {
  message: string;
  dateTime: string;
}
