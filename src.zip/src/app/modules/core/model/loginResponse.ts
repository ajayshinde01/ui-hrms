export interface LoginResponse {
  jwtToken: string;
  username: string;
  orgCode: string;
  division: string;
  role: string;
}
